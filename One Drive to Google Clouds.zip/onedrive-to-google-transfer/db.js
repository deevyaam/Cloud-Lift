const Database = require('better-sqlite3');
const db = new Database(process.env.DB_PATH || 'transfer.db');
db.pragma('journal_mode = WAL');
db.exec(`
create table if not exists tokens(provider text primary key, data text not null);
create table if not exists jobs(
  id integer primary key autoincrement, folder_id text, folder_name text,
  dest text, bucket text, status text default 'scanning', scanned integer default 0,
  error text, created_at text default current_timestamp);
create table if not exists files(
  id integer primary key autoincrement, job_id integer, item_id text, dir text, name text,
  size integer, mime text, status text default 'pending', retries integer default 0,
  error text, dest_kind text, dest_id text, unique(job_id, item_id));
create table if not exists maps(kind text, key text, value text, primary key(kind, key));
`);
module.exports = db;
